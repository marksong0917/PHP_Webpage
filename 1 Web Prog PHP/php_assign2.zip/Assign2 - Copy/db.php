<?php
$conn = new PDO('mysql:host=127.0.0.1:49260;dbname=localdb', 'azure','6#vWHD_$');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
